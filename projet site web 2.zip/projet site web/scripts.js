/// Suppose you have an array to store the added cart items

let cart = [];

function addToCart(productName, quantity, price, image) {
    const totalPrice = quantity * price;
    fetch('/add-to-cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({  productName, quantity, productPrice: price, productImage: image, totalPrice }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Lunettes ajoutées au panier');
            // Update cart count here
        }
    })
    .catch(error => console.error('Error:', error));
}

// Function to add an item to the cart
//function addToCart(productName,quantity) {
//    let cart = JSON.parse(localStorage.getItem('cart')) || [];
//    cart.push({productName: productName, quantity: quantity });
//    localStorage.setItem('cart', JSON.stringify(cart));
//     
//    // Update UI to show item added
//    alert("Item added to cart!");
//    updateCartCount();
//}

// Function to display the cart content on the "panier.html" page
function displayCart() {
    cart = JSON.parse(localStorage.getItem('cart')); // Get the cart object from the localStorage
    const cartItemsContainer = document.querySelector("#cart-items");
    cartItemsContainer.innerHTML = ''; // Clear the container
    let total = 0;
    let htmlContent = '';

    // Loop through the items in the cart
    cart.forEach((item, index) => {
        total += item.price * item.quantity; // Calculate total price
        // Create HTML content for each cart item
        htmlContent += `
            <div class="cart-item">
                    <img src="${product.image}" alt="${product.name}" width="100" height="100">
                    <span>${product.name}</span>
                    <span>${product.quantity}</span>
                    <span>${product.price} €</span>
                    <button onclick="removeFromCart(${index})">Remove</button>
                    </div>
            `;
    });

    // Add the items to the cart container
    cartItemsContainer.innerHTML = htmlContent;
    // Display the total
    cartItemsContainer.innerHTML += `<div class="total">Total: ${total.toFixed(2)} €</div>`;
}

// Function to remove an item from the cart
function removeFromCart(index) {
    cart[index].quantity -= 1;
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1); // Remove the item if the quantity is 0
    }
    displayCart(); // Update the cart display
}

document.addEventListener('DOMContentLoaded', function() {
    displayCart(); // Assurez-vous que cette fonction est définie dans votre scripts.js
});




