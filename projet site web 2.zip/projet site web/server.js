const express = require('express');
const app = express();
const path = require('path');

cart = [];

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, './')));
app.use(express.json()); // Parses JSON request bodies
app.use(express.urlencoded({ extended: true })); // Parses URL-encoded request bodies

const session = require('express-session');

app.use(session({
    secret: 'clesecrette', 
    resave: false,
    saveUninitialized: true,
}));

// Endpoint to get cart data
app.get('/get-cart', (req, res) => {
    console.log(req.session.cart);
    console.log("get-cart")
    res.json(req.session.cart || []);
});


// Endpoint to add item to cart
app.post('/add-to-cart', (req, res) => {
    console.log("add-to-cart");
    const { productName, quantity, productPrice, productImage, totalPrice } = req.body;

    // Ensure numeric values are correctly parsed
    const parsedQuantity = parseInt(quantity, 10);
    const parsedTotalPrice = parseFloat(totalPrice);

    if (!req.session.cart) {
        req.session.cart = [];
    }

    let productFound = false;
    req.session.cart.forEach(item => {
        if (item.productName === productName) {
            item.quantity += parsedQuantity;
            item.totalPrice += parsedTotalPrice;
            productFound = true;
        }
    });

    if (!productFound) {
        req.session.cart.push({ 
            productName, 
            quantity: parsedQuantity, 
            productPrice, 
            productImage, 
            totalPrice: parsedTotalPrice 
        });
    }

    res.json({ success: true, message: 'Produit ajouté au panier' });
});

app.post('/delete-from-cart', (req, res) => {
    const { productName } = req.body;
    
    if (req.session.cart) {
        req.session.cart = req.session.cart.filter(item => item.productName !== productName);
    }

    res.json({ success: true, message: 'Produit supprimé du panier' });
});




app.listen(3001, () => console.log('Server listening on port 3001'));